<?php

$conn = mysqli_connect('localhost','root','','flower') or die('connection failed');

?>